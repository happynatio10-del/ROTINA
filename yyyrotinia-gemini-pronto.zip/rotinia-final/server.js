const path = require('path');
const express = require('express');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const MODEL = process.env.GEMINI_MODEL || 'gemini-3.6-flash';

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname)));

function friendlyError(code, status = 500) {
  const messages = {
    MISSING_API_KEY: 'O Assistente ainda não está configurado no servidor.',
    INVALID_API_KEY: 'A conexão do Assistente precisa ser configurada novamente.',
    GEMINI_UNAVAILABLE: 'O Gemini está indisponível no momento. Tente novamente.',
    INVALID_REQUEST: 'Não consegui processar essa mensagem. Tente novamente.',
    EMPTY_ANSWER: 'O Assistente não conseguiu gerar uma resposta agora.'
  };
  return { status, body: { code, answer: messages[code] || 'Não consegui processar sua mensagem agora.' } };
}

function buildPrompt(message, conversation, tasks, userContext) {
  const safeConversation = Array.isArray(conversation) ? conversation.slice(-12) : [];
  const safeTasks = Array.isArray(tasks) ? tasks.slice(0, 80) : [];

  return `Você é o Assistente RotinIA, um assistente pessoal inteligente e profissional.

Ajude o usuário com rotina, tarefas, horários, prioridades, produtividade, hábitos, planejamento e organização pessoal.
Responda em português do Brasil, de forma clara, útil e natural. Não invente dados que não estejam no contexto.

Você pode sugerir ações sobre tarefas. Quando quiser propor alterações, responda também com um bloco JSON exatamente neste formato no final da resposta:
<ACTIONS>
{"actions":[{"type":"create_task","title":"...","time":"08:00","priority":"Média"}]}
</ACTIONS>
Tipos permitidos: create_task, update_task, complete_task, delete_task, suggest_schedule.
Para suggest_schedule use: {"type":"suggest_schedule","items":[{"title":"...","time":"09:00","priority":"Alta"}]}
Só inclua ações quando forem realmente úteis. Para perguntas normais, não inclua ACTIONS.

CONTEXTO DO USUÁRIO:
${JSON.stringify(userContext || {})}

TAREFAS ATUAIS:
${JSON.stringify(safeTasks)}

HISTÓRICO RECENTE:
${JSON.stringify(safeConversation)}

MENSAGEM ATUAL:
${message}`;
}

function parseAnswer(rawText) {
  const raw = String(rawText || '').trim();
  const match = raw.match(/<ACTIONS>\s*([\s\S]*?)\s*<\/ACTIONS>/i);
  let actions = [];
  let answer = raw;

  if (match) {
    try {
      const parsed = JSON.parse(match[1]);
      actions = Array.isArray(parsed.actions) ? parsed.actions : [];
    } catch (_) {
      actions = [];
    }
    answer = raw.replace(match[0], '').trim();
  }

  return { answer, actions };
}

app.post('/api/assistant', async (req, res) => {
  if (!process.env.GEMINI_API_KEY) {
    const e = friendlyError('MISSING_API_KEY');
    return res.status(e.status).json(e.body);
  }

  const { message, conversation = [], tasks = [], userContext = {} } = req.body || {};
  if (typeof message !== 'string' || !message.trim()) {
    const e = friendlyError('INVALID_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  try {
    const prompt = buildPrompt(message.trim(), conversation, tasks, userContext);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    let response;
    try {
      response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': process.env.GEMINI_API_KEY
        },
        body: JSON.stringify({
          system_instruction: {
            parts: [{ text: 'Você é o Assistente RotinIA, um assistente pessoal inteligente e profissional. Responda sempre em português do Brasil, seja claro, útil e natural.' }]
          },
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
        }),
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeout);
    }

    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const err = new Error(payload?.error?.message || 'Gemini request failed');
      err.status = response.status;
      throw err;
    }

    const rawText = payload?.candidates?.[0]?.content?.parts
      ?.map(part => part?.text || '')
      .join('')
      .trim();

    const parsed = parseAnswer(rawText);
    if (!parsed.answer) {
      const e = friendlyError('EMPTY_ANSWER');
      return res.status(e.status).json(e.body);
    }

    return res.json(parsed);
  } catch (error) {
    const status = Number(error?.status) || 500;
    if (status === 401 || status === 403 || /api.?key|unauth|permission/i.test(String(error?.message || ''))) {
      const e = friendlyError('INVALID_API_KEY', 502);
      return res.status(e.status).json(e.body);
    }
    if (status === 429 || status >= 500 || /timeout|fetch failed|network|unavailable|overloaded/i.test(String(error?.message || ''))) {
      const e = friendlyError('GEMINI_UNAVAILABLE', 503);
      return res.status(e.status).json(e.body);
    }
    console.error('Gemini request failed:', error?.message || error);
    const e = friendlyError('GEMINI_UNAVAILABLE', 502);
    return res.status(e.status).json(e.body);
  }
});

app.use((req, res, next) => {
  if (req.method === 'GET' && !req.path.startsWith('/api/')) {
    return res.sendFile(path.join(__dirname, 'index.html'));
  }
  next();
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`RotinIA rodando em http://localhost:${PORT}`);
});
