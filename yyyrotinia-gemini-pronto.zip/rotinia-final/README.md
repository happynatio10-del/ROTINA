# RotinIA

Assistente pessoal inteligente com Google Gemini.

## Configuração

1. Instale Node.js 20 ou superior.
2. Rode `npm install`.
3. Crie `.env` baseado em `.env.example` e configure `GEMINI_API_KEY`.
4. Rode `npm start`.
5. Abra `http://localhost:3000`.

A chave do Gemini fica somente no servidor.
